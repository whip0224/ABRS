import rawJson from "./snapshot.json"
import { prepare, type Network, type RawSnapshot } from "./engine"

let cached: Network | null = null

export function getNetwork(): Network {
  if (!cached) cached = prepare(rawJson as unknown as RawSnapshot)
  return cached
}
